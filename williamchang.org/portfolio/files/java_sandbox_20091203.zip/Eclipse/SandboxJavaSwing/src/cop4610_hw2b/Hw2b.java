/*
Name: William Chang
Course: COP 4610
Assignment title: Program 2A � Synchronized, Cooperating Threads � Lock Version
Date: 2008-02-20
*/

package cop4610_hw2b;

import java.util.Random;

/** Class Hw2b. */
public class Hw2b {
    /** Inner class BankAccount. */
    protected class BankAccount {
        /** Standard constructor. */
        BankAccount() {
            // Init.
            _accountBalance = 0;
            // Output header.
            outputHeader();
        }
        /** Deposit to account balance. */
        public synchronized void deposit(double value, String trusteeName) {
            // Deposit value to balance.
            _accountBalance += value;
            // Log state.
            outputDeposit(value, trusteeName);
            // Signal to one waiting thread.
            this.notify();
        }
        /** Withdraw from account balance. */
        public synchronized void withdraw(double value, String trusteeName) {
            try {
                // If withdraw value is below the account balance, then wait.
                while(value > _accountBalance) {
                    // Log state.
                    outputWithdrawError(value, trusteeName);
                    // Wait thread until signaled or interrupted.
                    this.wait();
                }
                // Withdraw value from balance.
                _accountBalance -= value;
                // Log state.
                outputWithdraw(value, trusteeName);
                // Signal to one waiting thread.
                this.notify();
            } catch(InterruptedException e) {
                // Print stack trace.
                e.printStackTrace();
            }
        }
        /** Get header for output. */
        public void outputHeader() {
            System.out.println("Deposit Threads\t\t\tWithdrawal Threads\t\t\tBalance");
            System.out.println("---------------\t\t\t------------------\t\t\t-------");
        }
        /** Output deposit. */
        public void outputDeposit(double value, String trusteeName) {
            System.out.printf("%s deposits $%.2f \t\t\t\t\t\t$%.2f\n", trusteeName, value, _accountBalance);
        }
        /** Output withdraw. */
        public void outputWithdraw(double value, String trusteeName) {
            System.out.printf("\t\t\t\t%s withdraws $%.2f \t\t$%.2f\n", trusteeName, value, _accountBalance);
        }
        /** Output withdraw error. */
        public void outputWithdrawError(double value, String trusteeName) {
            System.out.printf("\t\t\t\t%s attempts $%.2f withdrawal - Blocked - Insufficient Funds\n", trusteeName, value);
        }

        // Primitives.
        private double _accountBalance;
    }
    /** Inner class Trustee. */
    protected class Trustee implements Runnable {
        /** Argument constructor. */
        Trustee(int role, String name, BankAccount sharedAccount) {
            // Init.
            _rnd = new Random();
            _account = sharedAccount;
            _role = role;
            _name = name;
            _amount = 0;
        }
        /** Get name. */
        public String getName() {
            return _name;
        }
        /** Get amount. */
        public double getAmount(int minimum, int maximum) {
            // Get random number within range.
            _amount = minimum + _rnd.nextInt(maximum);
            // Has odd number.
            if(_amount % 2 != 0) {
                // Convert odd number to even number.
                _amount += 1;
            }
            return _amount;
        }
        /** Run thread. */
        public void run() {
            while(true) {
                try {
                    switch(_role) {
                        case ROLE_DEPOSITOR:
                            // Deposit amount.
                            _account.deposit(getAmount(1, 200), _name);
                            // Sleep for a length of time.
                            Thread.sleep(500 + _rnd.nextInt(SLEEP_MILLISECONDS));
                            break;
                        case ROLE_WITHDRAWER:
                            // Withdraw amount.
                            _account.withdraw(getAmount(1, 50), _name);
                            // Yield to other threads.
                            Thread.yield();
                            break;
                        default:
                            System.out.println("Error: No role set to trustee.");
                            return;
                    }
                } catch(InterruptedException e) {
                    // Print stack trace.
                    e.printStackTrace();
                }
            }
        }

        // Primitives.
        private int _role;
        private double _amount;
        private String _name;
        // Objects.
        private Random _rnd;
        private BankAccount _account;
        // Definitions.
        public static final int ROLE_DEPOSITOR = 2;
        public static final int ROLE_WITHDRAWER = 1;
    }

    /** Standard constructor. */
    Hw2b() {
        // Init.
        BankAccount a1 = new BankAccount();
        Thread d1 = new Thread(new Trustee(Trustee.ROLE_DEPOSITOR, "Thread 1", a1));
        Thread d2 = new Thread(new Trustee(Trustee.ROLE_DEPOSITOR, "Thread 2", a1));
        Thread d3 = new Thread(new Trustee(Trustee.ROLE_DEPOSITOR, "Thread 3", a1));
        Thread w1 = new Thread(new Trustee(Trustee.ROLE_WITHDRAWER, "Thread 4", a1));
        Thread w2 = new Thread(new Trustee(Trustee.ROLE_WITHDRAWER, "Thread 5", a1));
        Thread w3 = new Thread(new Trustee(Trustee.ROLE_WITHDRAWER, "Thread 6", a1));
        Thread w4 = new Thread(new Trustee(Trustee.ROLE_WITHDRAWER, "Thread 7", a1));
        // Start threads.
        d1.start();
        d2.start();
        d3.start();
        w1.start();
        w2.start();
        w3.start();
        w4.start();
    }
    /** Start program execution. */
    public static void main(String[] args) {
        // Init.
        new Hw2b();
    }

    // Definitions.
    public static final int SLEEP_MILLISECONDS = 2000;
}