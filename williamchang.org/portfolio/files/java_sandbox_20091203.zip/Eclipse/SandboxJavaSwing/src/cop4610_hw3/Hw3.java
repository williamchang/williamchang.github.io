/*
Name: William Chang
Course: COP 4610
Assignment Title: Program Assignment 3: Java, JDBC, and MySQL
Date: 2008-03-19
*/

package cop4610_hw3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;

/** Class Hw3. */
public class Hw3 {
    /** Inner class Model (Model) using Model-View-Controller (MVC) architectural pattern. */
    protected class Model  {
        /** Standard constructor. */
        Model() {
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            _databaseDriver = DATABASE_DEFAULT_DRIVER;
            _databaseConnectionUsername = DATABASE_DEFAULT_USERNAME;
            _databaseConnectionPassword = DATABASE_DEFAULT_PASSWORD;
        }
        /** Get database driver. */
        public String getDatabaseDriver() {
            return _databaseDriver;
        }
        /** Get database connection url. */
        public String getDatabaseConnectionUrl() {
            return _databaseConnectionUrl;
        }
        /** Get database statement. */
        public String getDatabaseStatement() {
            return _databaseStatement;
        }
        /** Get database result. */
        public ResultSet getDatabaseResult() {
            return _databaseResult;
        }
        /** Set database driver. */
        public void setDatabaseDriver(String driver) {
            _databaseDriver = driver;
        }
        /** Set database connection url. */
        public void setDatabaseConnectionUrl(String url) {
            _databaseConnectionUrl = url;
        }
        /** Set database connection username and password. */
        public void setDatabaseConnectionUsernameAndPassword(String username, String password) {
            _databaseConnectionUsername = username;
            _databaseConnectionPassword = password;
        }
        /** Set database statement. */
        public void setDatabaseStatement(String statement) {
            _databaseStatement = statement;
        }
        /** Initialize database table. */
        public ResultSetTableModel initDatabaseTable() {
            try {
                _databaseResultTable = new ResultSetTableModel(_databaseDriver, _databaseConnectionUrl, _databaseConnectionUsername, _databaseConnectionPassword, _databaseStatement);
            } catch(ClassNotFoundException e) {
                e.printStackTrace();
                return null;
            } catch(SQLException e) {
                e.printStackTrace();
                return null;
            }
            return _databaseResultTable;
        }
        /** Get database table. */
        public ResultSetTableModel getDatabaseTable() {
            return _databaseResultTable;
        }
        /** Test database connection. */
        public Boolean databaseConnectTest() {
            // Load the database driver.
            try {
                Class.forName(_databaseDriver);
                System.out.println("JDBC driver loaded.");
            } catch(ClassNotFoundException e) {
                e.printStackTrace();
                return false;
            }
            try {
                // Establish a database connection.
                _databaseConnection = DriverManager.getConnection(_databaseConnectionUrl, _databaseConnectionUsername, _databaseConnectionPassword);
                System.out.println("Database connected and opened.");
                // Output database metadata.
                DatabaseMetaData dbMetaData = _databaseConnection.getMetaData();
                System.out.println("JDBC driver name: " + dbMetaData.getDriverName() );
                System.out.println("JDBC driver version: " + dbMetaData.getDriverVersion());
                System.out.println("Driver major version: " + dbMetaData.getDriverMajorVersion());
                System.out.println("Driver minor version: " + dbMetaData.getDriverMinorVersion());
                // Close database connection
                _databaseConnection.close();
            } catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
            return true;
        }
        /** Connect database. */
        public Boolean databaseConnect() {
            // Load the database driver.
            try {
                Class.forName(_databaseDriver);
                System.out.println("JDBC driver loaded.");
            } catch(ClassNotFoundException e) {
                e.printStackTrace();
                return false;
            }
            try {
                // Establish a database connection.
                _databaseConnection = DriverManager.getConnection(_databaseConnectionUrl, _databaseConnectionUsername, _databaseConnectionPassword);
                System.out.println("Database connected and opened.");
                // Output database metadata.
                DatabaseMetaData dbMetaData = _databaseConnection.getMetaData();
                System.out.println("JDBC driver name: " + dbMetaData.getDriverName());
                System.out.println("JDBC driver version: " + dbMetaData.getDriverVersion());
                System.out.println("Driver major version: " + dbMetaData.getDriverMajorVersion());
                System.out.println("Driver minor version: " + dbMetaData.getDriverMinorVersion());
            } catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
            return true;
        }
        /** Execute database. */
        public Boolean databaseExecute() {
            try {
                // Create database statement.
                Statement databaseStatement = _databaseConnection.createStatement();
                // Execute database statement.
                _databaseResult = databaseStatement.executeQuery(_databaseStatement);
                // Close database connection
                _databaseConnection.close();
                System.out.println("Database connection closed.");
            } catch(SQLException e) {
                e.printStackTrace();
                return false;
            }
            return true;
        }

        // Database objects.
        private Connection _databaseConnection;
        private ResultSet _databaseResult;
        private ResultSetTableModel _databaseResultTable;
        // Primitives.
        private String _databaseDriver;
        private String _databaseConnectionUrl;
        private String _databaseConnectionUsername;
        private String _databaseConnectionPassword;
        private String _databaseStatement;
        // Definitions.
        public final String TITLE = "SQL Client GUI";
        public final String TITLE_CONNECTION = "Database Connection";
        public final String TITLE_COMMAND = "SQL Command";
        public final String TITLE_OUTPUT = "SQL Result";
        public final String DATABASE_DEFAULT_DRIVER = "com.mysql.jdbc.Driver";
        public final String DATABASE_DEFAULT_URL = "jdbc:mysql://localhost/prog3";
        public final String DATABASE_DEFAULT_USERNAME = "root";
        public final String DATABASE_DEFAULT_PASSWORD = "";
    }
    /** Inner class View (View) using Model-View-Controller (MVC) architectural pattern. */
    protected class View {
        /** Argument constructor. */
        View(Model m) {
            _model = m;
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            // Setup window.
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch(Exception e) {
                e.printStackTrace();
            }
            _frameWindow = new JFrame(_model.TITLE);
            _frameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // Create panels.
            JPanel pnlContainer = new JPanel(new BorderLayout());
            JPanel pnlConnection = new JPanel(new BorderLayout());
            JPanel pnlCommand = new JPanel(new BorderLayout());
            JPanel pnlOutput = new JPanel(new BorderLayout());
            // Setup panels.
            pnlConnection.setBorder(BorderFactory.createTitledBorder(_model.TITLE_CONNECTION));
            pnlCommand.setBorder(BorderFactory.createTitledBorder(_model.TITLE_COMMAND));
            pnlOutput.setBorder(BorderFactory.createTitledBorder(_model.TITLE_OUTPUT));
            // Create sub-container panel.
            JPanel pnlSubContainerNorth = new JPanel(new BorderLayout());
            pnlSubContainerNorth.add(pnlConnection, BorderLayout.WEST);
            pnlSubContainerNorth.add(pnlCommand, BorderLayout.CENTER);
            // Add to container panel.
            pnlContainer.add(pnlSubContainerNorth, BorderLayout.NORTH);
            pnlContainer.add(pnlOutput, BorderLayout.CENTER);

            // Setup components for connection.
            initFormConnection(pnlConnection);

            // Setup components for command.
            _txtCommandStatement = new JTextArea();
            _txtCommandStatement.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _txtCommandStatement.setLineWrap(true);
            _txtCommandStatement.setWrapStyleWord(true);
            _txtCommandStatement.setPreferredSize(new Dimension(320, 160));
            _btnCommandClear = new JButton();
            _btnCommandExecute = new JButton();
            // Create control panel for command.
            JPanel pnlCommandControls = new JPanel();
            pnlCommandControls.add(_btnCommandExecute);
            pnlCommandControls.add(_btnCommandClear);
            // Add to command panel.
            pnlCommand.add(_txtCommandStatement, BorderLayout.CENTER);
            pnlCommand.add(pnlCommandControls,  BorderLayout.SOUTH);

            // Setup components for output.
            JPanel pnlOutputResults = new JPanel(new BorderLayout());
            pnlOutputResults.setBorder(new BevelBorder(BevelBorder.LOWERED));
            pnlOutputResults.setBackground(Color.white);
            pnlOutputResults.setPreferredSize(new Dimension(320, 160));
            _lblOutputStatus = new JLabel();
            _lblOutputStatus.setVisible(false);
            _tblOutputTable = new JTable();
            _scrollOutputTable = new JScrollPane(_tblOutputTable);
            _scrollOutputTable.setBorder(BorderFactory.createEmptyBorder());
            _scrollOutputTable.getViewport().setBackground(Color.WHITE);
            _scrollOutputTable.setVisible(true);
            _btnOutputClear = new JButton();
            // Create control panel for output.
            JPanel pnlOutputControls = new JPanel();
            pnlOutputControls.add(_btnOutputClear);
            // Add to output result panel.
            pnlOutputResults.add(_lblOutputStatus, BorderLayout.NORTH);
            pnlOutputResults.add(_scrollOutputTable, BorderLayout.CENTER);
            // Add to output panel.
            pnlOutput.add(pnlOutputResults, BorderLayout.CENTER);
            pnlOutput.add(pnlOutputControls, BorderLayout.SOUTH);

            // Reset components.
            reset();
            // Add components to window.
            _frameWindow.getContentPane().add(pnlContainer);
            // Show window.
            _frameWindow.pack();
            _frameWindow.setVisible(false);
            // Set window properties after at the end.
            _frameWindow.setLocationRelativeTo(null);
        }
        /** Initialize form. */
        protected void initFormConnection(JPanel p) {
            // Setup combobox.
            _cbConnectionDriver = new JComboBox();
            _cbConnectionDriver.setBorder(BorderFactory.createEmptyBorder());
            // Setup label.
            _lblConnectionDriver = new JLabel();
            _lblConnectionDriver.setHorizontalAlignment(JLabel.TRAILING);

            // Setup combobox.
            _tfConnectionUrl = new JTextField(32);
            _tfConnectionUrl.setBorder(new BevelBorder(BevelBorder.LOWERED));
            // Setup label.
            _lblConnectionUrl = new JLabel();
            _lblConnectionUrl.setHorizontalAlignment(JLabel.TRAILING);

            // Setup textfield.
            _tfConnectionUsername = new JTextField(32);
            _tfConnectionUsername.setBorder(new BevelBorder(BevelBorder.LOWERED));
            // Setup label.
            _lblConnectionUsername = new JLabel();
            _lblConnectionUsername.setHorizontalAlignment(JLabel.TRAILING);
            _lblConnectionUsername.setLabelFor(_tfConnectionUsername);

            // Setup textfield.
            _tfConnectionPassword = new JTextField(32);
            _tfConnectionPassword.setBorder(new BevelBorder(BevelBorder.LOWERED));
            // Setup label.
            _lblConnectionPassword = new JLabel();
            _lblConnectionPassword.setHorizontalAlignment(JLabel.TRAILING);
            _lblConnectionPassword.setLabelFor(_tfConnectionPassword);

            // Setup button.
            _btnConnectionDatabase = new JButton();
            // Setup label.
            _lblConnectionStatus = new JLabel();
            _lblConnectionStatus.setHorizontalAlignment(SwingConstants.CENTER);
            _lblConnectionStatus.setForeground(Color.RED);
            _lblConnectionStatus.setLabelFor(_btnConnectionDatabase);

            // Create panel for labels.
            JPanel pnlLabels = new JPanel(new GridLayout(0, 1, 0, 10));
            pnlLabels.add(_lblConnectionDriver);
            pnlLabels.add(_lblConnectionUrl);
            pnlLabels.add(_lblConnectionUsername);
            pnlLabels.add(_lblConnectionPassword);
            // Create panel for inputs.
            JPanel pnlInputs = new JPanel(new GridLayout(0, 1, 0, 4));
            pnlInputs.add(_cbConnectionDriver);
            pnlInputs.add(_tfConnectionUrl);
            pnlInputs.add(_tfConnectionUsername);
            pnlInputs.add(_tfConnectionPassword);

            // Create panel for form.
            JPanel pnlContainer = new JPanel();
            pnlContainer.setLayout(new BoxLayout(pnlContainer, BoxLayout.Y_AXIS));
            JPanel pnlForm = new JPanel();
            // Add to form panel.
            pnlForm.add(pnlLabels);
            pnlForm.add(pnlInputs);
            // Add to container panel.
            pnlContainer.add(pnlForm);
            pnlContainer.add(_btnConnectionDatabase);
            // Add to source panel.
            p.add(pnlContainer, BorderLayout.NORTH);
            p.add(_lblConnectionStatus, BorderLayout.CENTER);
        }
        /** Initialize output table. */
        public void initOutputTable() {
            _model.initDatabaseTable();
            // Set component delegate for database table model.
            _tblOutputTable.setModel(_model.initDatabaseTable());
        }
        /** Set window visibility. */
        public void setWindowVisible(boolean b) {
            _frameWindow.setVisible(b);
        }
        /** Set component's text. */
        public void setComponentTexts() {
            _lblConnectionDriver.setText("JDBC Driver:");
            _lblConnectionUrl.setText("Database URL:");
            _lblConnectionUsername.setText("Username:");
            _lblConnectionPassword.setText("Password:");
            _lblConnectionStatus.setText("Status: No connection available.");
            _cbConnectionDriver.addItem(new String(_model.DATABASE_DEFAULT_DRIVER));
            _tfConnectionUrl.setText(_model.DATABASE_DEFAULT_URL);
            _tfConnectionUsername.setText(_model.DATABASE_DEFAULT_USERNAME);
            _tfConnectionPassword.setText(_model.DATABASE_DEFAULT_PASSWORD);
            _txtCommandStatement.setText("");
            _btnConnectionDatabase.setText("Connect Database");
            _btnCommandExecute.setText("Execute Command");
            _btnCommandClear.setText("Clear Command");
            _btnOutputClear.setText("Clear Result");
        }
        public void addListenerButton1(ActionListener al) {
            _btnConnectionDatabase.addActionListener(al);
        }
        public void addListenerButton2(ActionListener al) {
            _btnCommandExecute.addActionListener(al);
        }
        public void addListenerButton3(ActionListener al) {
            _btnCommandClear.addActionListener(al);
        }
        public void addListenerButton4(ActionListener al) {
            _btnOutputClear.addActionListener(al);
        }
        public String getConnectionDriver() {
            return (String)_cbConnectionDriver.getSelectedItem();
        }
        public String getConnectionUrl() {
            return _tfConnectionUrl.getText();
        }
        public String getConnectionUsername() {
            return _tfConnectionUsername.getText();
        }
        public String getConnectionPassword() {
            return _tfConnectionPassword.getText();
        }
        public String getConnectionStatus() {
            return _lblConnectionStatus.getText();
        }
        public String getCommandStatement() {
            return _txtCommandStatement.getText();
        }
        public JTable getOutputTable() {
            return _tblOutputTable;
        }
        public String getOutputStatus() {
            return _lblOutputStatus.getText();
        }
        public void setConnectionStatus(String value) {
            _lblConnectionStatus.setText(value);
        }
        public void setCommandStatement(String value) {
            _txtCommandStatement.setText(value);
        }
        public void setOutputStatus(String value) {
            _lblOutputStatus.setText(value);
        }
        public void setEnabledButton1(boolean b) {
            _btnConnectionDatabase.setEnabled(b);
        }
        public void setEnabledButton2(boolean b) {
            _btnCommandExecute.setEnabled(b);
        }
        public void setEnabledButton3(boolean b) {
            _btnCommandClear.setEnabled(b);
        }
        public void setEnabledButton4(boolean b) {
            _btnOutputClear.setEnabled(b);
        }
        public void setVisible1(boolean b) {
            _lblOutputStatus.setVisible(b);
        }
        public void setVisible2(boolean b) {
            _scrollOutputTable.setVisible(b);
            SwingUtilities.updateComponentTreeUI(_scrollOutputTable);
        }
        /** Reset. */
        public void reset() {
            setComponentTexts();
        }

        // Implement Model-View-Controller (MVC) architectural pattern.
        private Model _model;
        // Frame (window).
        private JFrame _frameWindow;
        // Components.
        private JLabel _lblConnectionDriver;
        private JLabel _lblConnectionUrl;
        private JLabel _lblConnectionUsername;
        private JLabel _lblConnectionPassword;
        private JLabel _lblConnectionStatus;
        private JLabel _lblOutputStatus;
        private JComboBox _cbConnectionDriver;
        private JTextField _tfConnectionUrl;
        private JTextField _tfConnectionUsername;
        private JTextField _tfConnectionPassword;
        private JTextArea _txtCommandStatement;
        private JScrollPane _scrollOutputTable;
        private JTable _tblOutputTable;
        private JButton _btnConnectionDatabase;
        private JButton _btnCommandExecute;
        private JButton _btnCommandClear;
        private JButton _btnOutputClear;
    }
    /** Inner class Controller (Controller) using Model-View-Controller (MVC) architectural pattern. */
    protected class Controller {
        /** Argument constructor. */
        Controller(Model m, View v) {
            _model = m;
            _view = v;
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            _databaseConnectionTested = false;
            // Add listeners to the view.
            _view.addListenerButton1(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _model.setDatabaseDriver(_view.getConnectionDriver());
                    _model.setDatabaseConnectionUrl(_view.getConnectionUrl());
                    _model.setDatabaseConnectionUsernameAndPassword(_view.getConnectionUsername(), _view.getConnectionPassword());
                    if(_model.databaseConnectTest()) {
                        _databaseConnectionTested = true;
                        _view.setConnectionStatus("Status: Database connected.");
                    } else {
                        _databaseConnectionTested = false;
                        _view.setConnectionStatus("Status: Connection failed.");
                    }
                }
            });
            _view.addListenerButton2(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if(!_databaseConnectionTested) {
                        _view.setVisible1(true);
                        _view.setVisible2(false);
                        _view.setOutputStatus("No database connection.");
                        return;
                    }
                    if(_view.getCommandStatement().length() == 0) {
                        _view.setVisible1(true);
                        _view.setVisible2(false);
                        _view.setOutputStatus("Command statement is empty.");
                        return;
                    }
                    _view.setVisible1(false);
                    _view.setVisible2(true);
                    _model.setDatabaseStatement(_view.getCommandStatement());
                    _view.initOutputTable();
                    /*
                    try {
                        _model.getDatabaseTable().setQuery(_view.getCommandStatement());
                    } catch(SQLException ex) {
                        ex.printStackTrace();
                        _view.setOutputStatus("Failed.");
                    }
                    _model.getDatabaseTable().disconnectFromDatabase();
                    */
                }
            });
            _view.addListenerButton3(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _view.setCommandStatement("");
                }
            });
            _view.addListenerButton4(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _view.setOutputStatus("");
                    _view.setVisible1(false);
                    _view.setVisible2(false);
                }
            });
        }

        // Primitives.
        private boolean _databaseConnectionTested;
        // Implement Model-View-Controller (MVC) architectural pattern.
        private Model _model;
        private View _view;
    }
    /** Standard constructor. */
    Hw3() {
        Model m = new Model();
        View v = new View(m);
        new Controller(m, v);
        v.setWindowVisible(true);
    }
    /** Start program execution. */
    public static void main(String[] args) {
        // Schedule a job for the event-dispatching thread.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Applications.
                new Hw3();
            }
        });
    }
}
