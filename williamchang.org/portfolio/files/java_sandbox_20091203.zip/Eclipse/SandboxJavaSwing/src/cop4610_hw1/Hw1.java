/*
Name: William Chang
Course: COP 4610
Assignment title: Program Assignment 1: Event-Driven Programming
Date: 2008-01-30
*/

package cop4610_hw1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;

/** Class Hw1 (MVC) using Model-View-Controller (MVC) architectural pattern. */
public class Hw1 {
    /** Inner class Model (Model) using Model-View-Controller (MVC) architectural pattern. */
    protected class Model {
        /** Standard constructor. */
        Model() {
            initCommon();
            _dataFileRead = DATA_FILE_READ;
            _dataFileWrite = DATA_FILE_WRITE;
            readDataFile(_dataFileRead);
        }
        /** Argument constructor. */
        Model(String dataFileRead, String dataFileWrite) {
            initCommon();
            _dataFileRead = dataFileRead;
            _dataFileWrite = dataFileWrite;
            readDataFile(_dataFileRead);
        }
        /** Initialize common. */
        protected void initCommon() {
            _htDataItems = new HashMap<Integer, DataItem>();
            _htDataItemsByList = new HashMap<String, DataItem>();
            _htDataOrders = new HashMap<Integer, DataOrder>();
            _ordersCount = 0;
            _ordersMax = 0;
            _taxRate = 0.06;
            _ordersSubtotal = 0;
            _isOrdersFinished = false;
        }
        /** Read data file. */
        protected void readDataFile(String filename) {
            Scanner fin = null;
            try {
                fin = new Scanner(new File(filename)).useDelimiter(", *|\n|\r\n|\r");
                while(fin.hasNext()) {
                    // Get tokens.
                    int parameter1 = fin.nextInt();
                    String parameter2 = fin.next();
                    double parameter3 = fin.nextDouble();
                    // Add tokens to collections.
                    DataItem din = new DataItem(parameter1, parameter2, parameter3);
                    _htDataItems.put(parameter1, din);
                    _htDataItemsByList.put(parameter2 + " $" + parameter3, din);
                }
            } catch(Exception e) {
                if(e instanceof FileNotFoundException) {
                    System.out.println("Data file not found.");
                } else {
                    e.printStackTrace();
                    System.out.println("Could not interpret file correctly.");
                }
            } finally {
                if(fin != null) {
                    fin.close();
                }
            }
        }
        /** Write data file. */
        protected void writeDataFile(String filename) {
            PrintWriter fout = null;
            try {
                fout = new PrintWriter(new FileWriter(new File(filename), true));
                // Get items from collection.
                for(int i=0;i<_htDataOrders.size();i++) {
                    fout.println(_htDataOrders.get(i).toStringFile());
                }
            } catch(Exception e) {
                System.out.println("Error writing file: " + e);
            } finally {
                if(fout != null) {
                    fout.close();
                }
            }
        }
        public boolean createOrder(int pId, int pQuantity) {
            if(_htDataItems.get(pId) != null) {
                _curOrder = new DataOrder(_htDataItems.get(pId).id, _htDataItems.get(pId).title, _htDataItems.get(pId).price, pQuantity);
                return true;
            } else {
                return false;
            }
        }
        public void createOrder(int pId, String pTitle, double pPrice, int pQuantity) {
            _curOrder = new DataOrder(pId, pTitle, pPrice, pQuantity);
        }
        public String getOrderDateTimeTransactionLast() {
            return _curOrder.dateLastTranscation;
        }
        public DataItem getDataItem(int id) {
            return _htDataItems.get(id);
        }
        public int getDataItemId(String s) {
            if(_htDataItemsByList.get(s) != null) {
                return _htDataItemsByList.get(s).id;
            } else {
                return -1;
            }
        }
        public int getOrdersCount() {
            return _ordersCount;
        }
        public int getOrdersMax() {
            return _ordersMax;
        }
        public double getOrdersSubtotal() {
            return _ordersSubtotal;
        }
        public double getTaxRate() {
            return _taxRate;
        }
        public double getTaxAmount() {
            return _taxRate * _ordersSubtotal;
        }
        public double getOrdersTotal() {
            return _ordersSubtotal + (_taxRate * _ordersSubtotal);
        }
        public void setOrder() {
            _curOrder.setIdTransaction();
            _ordersSubtotal += _curOrder.priceSubtotal;
            _htDataOrders.put(_ordersCount, _curOrder);
            _ordersCount++;
        }
        public void setOrdersMax(int num) {
            _ordersMax = num;
        }
        public void setOrdersFinished() {
            writeDataFile(_dataFileWrite);
            _isOrdersFinished = true;
        }
        public boolean isOrdersFinished() {
            return _isOrdersFinished;
        }
        public String toStringOrder() {
            return _curOrder.toString();
        }
        public String toStringOrders() {
            String s = new String();
            for(int i=0;i<_htDataOrders.size();i++) {
                s += (i + 1) + ". " + _htDataOrders.get(i).toString() + "\n";
            }
            return s;
        }
        /** Reset orders. */
        public void resetOrders() {
            _ordersCount = 0;
            _ordersSubtotal = 0;
            _htDataOrders = new HashMap<Integer, DataOrder>();
            _isOrdersFinished = false;
        }
        /** Exit program. */
        public void exit() {
            System.exit(0);
        }

        /** Inner class DataItem. */
        public class DataItem {
            DataItem(int pId, String pTitle, double pPrice) {
                this.id = pId;
                this.title = pTitle;
                this.price = pPrice;
            }
            public String toString() {
                return this.id + " " + this.title + " $" + this.price;
            }
            // Fields.
            public int id;
            public String title;
            public double price;
        }
        /** Inner class DataOrder. */
        public class DataOrder {
            DataOrder(int pId, String pTitle, double pPrice, int pQuantity) {
                this.id = pId;
                this.title = pTitle;
                this.price = pPrice;
                this.quantity = pQuantity;
                this.priceDiscount = getPriceDiscount(pQuantity);
                this.priceSubtotal = getPriceSubtotal(pQuantity, pPrice, this.priceDiscount);
            }
            protected double getPriceDiscount(int pQuantity) {
                if(1 <= pQuantity && pQuantity <= 4) {
                    return 0;
                } else if(5 <= pQuantity && pQuantity <= 9) {
                    return 0.1;
                } else if(10 <= pQuantity && pQuantity <= 14) {
                    return 0.15;
                } else if(15 <= pQuantity) {
                    return 0.2;
                } else {
                    return 0;
                }
            }
            protected double getPriceSubtotal(int pQuantity, double pPrice, double pPriceDiscount) {
                return pQuantity * pPrice - (pQuantity * pPrice * pPriceDiscount);
            }
            public void setIdTransaction() {
                this.idTransaction = getDataTimeNow("yyMMddhhmmss");
                this.dateLastTranscation = getDataTimeNow("dd/MM/yyyy hh:mm:ss a z");
            }
            public String toString() {
                return this.id + " " + this.title + " $" + this.price + " " + this.quantity + " " + toStringDecimalToPercent(this.priceDiscount) + " $" + toStringDecimalRoundTwo(this.priceSubtotal);
            }
            public String toStringFile() {
                return this.idTransaction + ", " + this.id + ", " + this.title + ", " + this.price + ", " + this.quantity + ", " + this.priceDiscount + ", " + toStringDecimalRoundTwo(this.priceSubtotal) + ", " + this.dateLastTranscation;
            }
            // Fields.
            public int id;
            public String title;
            public double price;
            public String idTransaction;
            public int quantity;
            public double priceDiscount;
            public double priceSubtotal;
            public String dateLastTranscation;
        }

        // Objects.
        private DataOrder _curOrder;
        // Collections.
        private HashMap<Integer, DataItem> _htDataItems;
        private HashMap<String, DataItem> _htDataItemsByList;
        private HashMap<Integer, DataOrder> _htDataOrders;
        // Primitives.
        private int _ordersCount;
        private int _ordersMax;
        private double _taxRate;
        private double _ordersSubtotal;
        private boolean _isOrdersFinished;
        private String _dataFileRead;
        private String _dataFileWrite;
        // Definitions.
        public final String TITLE = "Mark's World of Music";
    }
    /** Inner class View (View) using Model-View-Controller (MVC) architectural pattern. */
    protected class View {
        /** Argument constructor. */
        View(Model m) {
            _model = m;
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            // Setup window.
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch(Exception e) {
                e.printStackTrace();
            }
            _frameWindow = new JFrame(_model.TITLE);
            _frameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // Setup form layout.
            JPanel pnlFormLayout = new JPanel(new SpringLayout());
            // Create form inputs.
            JPanel pnlFormInputs = new JPanel(new SpringLayout());
            initFormInputElements(pnlFormInputs);
            SpringUtilities.makeCompactGrid(pnlFormInputs, pnlFormInputs.getComponentCount() / 2, 2, 6, 6, 6, 6);
            pnlFormLayout.add(pnlFormInputs);
            // Create form controls.
            JPanel pnlFormControls = new JPanel(new SpringLayout());
            initFormControlElements(pnlFormControls);
            SpringUtilities.makeCompactGrid(pnlFormControls, 1, pnlFormControls.getComponentCount(), 6, 6, 6, 6);
            pnlFormLayout.add(pnlFormControls);
            // Setup components.
            reset();
            // Add components to window.
            SpringUtilities.makeCompactGrid(pnlFormLayout, 2, 1, 6, 6, 6, 6);
            _frameWindow.getContentPane().add(pnlFormLayout);
            // Show window.
            _frameWindow.pack();
            _frameWindow.setVisible(false);
            // Set window properties after at the end.
            _frameWindow.setLocationRelativeTo(null);
        }
        /** Initialize form input elements. */
        protected void initFormInputElements(JPanel p) {
            // Setup label.
            _lblOrderTotalItems = new JLabel();
            _lblOrderTotalItems.setHorizontalAlignment(JLabel.TRAILING);
            p.add(_lblOrderTotalItems);
            // Setup textfield.
            _tfOrderTotalItems = new JTextField(TEXTFIELD_COLUMNS);
            _tfOrderTotalItems.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _lblOrderTotalItems.setLabelFor(_tfOrderTotalItems);
            p.add(_tfOrderTotalItems);
            // Setup label.
            _lblOrderItemId = new JLabel();
            _lblOrderItemId.setHorizontalAlignment(JLabel.TRAILING);
            p.add(_lblOrderItemId);
            // Setup textfield.
            _tfOrderItemId = new JTextField(32);
            _tfOrderItemId.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _lblOrderItemId.setLabelFor(_tfOrderItemId);
            p.add(_tfOrderItemId);
            // Setup label.
            _lblOrderItemQuantity = new JLabel();
            _lblOrderItemQuantity.setHorizontalAlignment(JLabel.TRAILING);
            p.add(_lblOrderItemQuantity);
            // Setup textfield.
            _tfOrderItemQuantity = new JTextField(TEXTFIELD_COLUMNS);
            _tfOrderItemQuantity.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _lblOrderItemQuantity.setLabelFor(_tfOrderItemQuantity);
            p.add(_tfOrderItemQuantity);
            // Setup label.
            _lblOrderItemInformation = new JLabel();
            _lblOrderItemInformation.setHorizontalAlignment(JLabel.TRAILING);
            p.add(_lblOrderItemInformation);
            // Setup textfield.
            _tfOrderItemInformation = new JTextField(TEXTFIELD_COLUMNS);
            _tfOrderItemInformation.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _tfOrderItemInformation.setEditable(false);
            _lblOrderItemInformation.setLabelFor(_tfOrderItemInformation);
            p.add(_tfOrderItemInformation);
            // Setup label.
            _lblOrderPriceSubtotal = new JLabel();
            _lblOrderPriceSubtotal.setHorizontalAlignment(JLabel.TRAILING);
            p.add(_lblOrderPriceSubtotal);
            // Setup textfield.
            _tfOrderPriceSubtotal = new JTextField(TEXTFIELD_COLUMNS);
            _tfOrderPriceSubtotal.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _tfOrderPriceSubtotal.setEditable(false);
            _lblOrderPriceSubtotal.setLabelFor(_tfOrderPriceSubtotal);
            p.add(_tfOrderPriceSubtotal);
        }
        /** Initialize form control (buttons) elements. */
        protected void initFormControlElements(JPanel p) {
            // Setup button.
            _btnOpen = new JButton();
            p.add(_btnOpen);
            _btnProcess = new JButton();
            p.add(_btnProcess);
            _btnConfirm = new JButton();
            p.add(_btnConfirm);
            _btnOrderView = new JButton();
            p.add(_btnOrderView);
            _btnOrderFinish = new JButton();
            p.add(_btnOrderFinish);
            _btnOrderNew = new JButton();
            p.add(_btnOrderNew);
            _btnExit = new JButton();
            p.add(_btnExit);
        }

        public void addMouseListenerOrderItemId(MouseListener ml) {
            _tfOrderItemId.addMouseListener(ml);
        }
        public void addListenerOpen(ActionListener al) {
            _btnOpen.addActionListener(al);
        }
        public void addListenerProcess(ActionListener al) {
            _btnProcess.addActionListener(al);
        }
        public void addListenerConfirm(ActionListener al) {
            _btnConfirm.addActionListener(al);
        }
        public void addListenerOrderView(ActionListener al) {
            _btnOrderView.addActionListener(al);
        }
        public void addListenerOrderFinish(ActionListener al) {
            _btnOrderFinish.addActionListener(al);
        }
        public void addListenerOrderNew(ActionListener al) {
            _btnOrderNew.addActionListener(al);
        }
        public void addListenerExit(ActionListener al) {
            _btnExit.addActionListener(al);
        }
        public String getOrderTotalItems() {
            return _tfOrderTotalItems.getText();
        }
        public String getOrderItemId() {
            return _tfOrderItemId.getText();
        }
        public String getOrderItemQuantity() {
            return _tfOrderItemQuantity.getText();
        }
        public void setWindowVisible(boolean b) {
            _frameWindow.setVisible(b);
        }
        public void setComponentTexts(int num, int total) {
            _lblOrderTotalItems.setText("Enter number of items in this order:");
            _lblOrderItemId.setText("Enter CD ID for Item #" + num + ":");
            _lblOrderItemQuantity.setText("Enter quantity for Item #" + num + ":");
            _lblOrderItemInformation.setText("Item #" + num + " info:");
            _lblOrderPriceSubtotal.setText("Order subtotal for " + total + " item(s):");
            _btnOpen.setText("Open");
            _btnProcess.setText("Process Item #" + num);
            _btnConfirm.setText("Confirm Item #" + num);
            _btnOrderView.setText("View Order");
            _btnOrderFinish.setText("Finish Order");
            _btnOrderNew.setText("New Order");
            _btnExit.setText("Exit");
        }
        public void setEditableOrderTotalItems(boolean b) {
            _tfOrderTotalItems.setEditable(b);
        }
        public void setEnabledButton1(boolean b) {
            _btnProcess.setEnabled(b);
        }
        public void setEnabledButton2(boolean b) {
            _btnConfirm.setEnabled(b);
        }
        public void setEnabledButton3(boolean b) {
            _btnOrderView.setEnabled(b);
        }
        public void setEnabledButton4(boolean b) {
            _btnOrderFinish.setEnabled(b);
        }
        public void setOrderTotalItems(String value) {
            _tfOrderTotalItems.setText(value);
        }
        public void setOrderItemId(String value) {
            _tfOrderItemId.setText(value);
        }
        public void setOrderItemQuantity(String value) {
            _tfOrderItemQuantity.setText(value);
        }
        public void setOrderItemInformation(String value) {
            _tfOrderItemInformation.setText(value);
        }
        public void setOrderPriceSubtotal(String value) {
            _tfOrderPriceSubtotal.setText(value);
        }
        /** Reset. */
        public void reset() {
            setComponentTexts(1, 0);
            _btnProcess.setEnabled(true);
            _btnConfirm.setEnabled(false);
            _btnOrderView.setEnabled(false);
            _btnOrderFinish.setEnabled(false);
            _tfOrderTotalItems.setEditable(true);
            _tfOrderTotalItems.setText("");
            _tfOrderItemId.setText("");
            _tfOrderItemQuantity.setText("");
            _tfOrderItemInformation.setText("");
            _tfOrderPriceSubtotal.setText("");
            _tfOrderItemId.setEditable(true);
            _tfOrderItemQuantity.setEditable(true);
        }
        /** Reset for next entry. */
        public void resetEntry(int num, int total) {
            setComponentTexts(num, total);
            _btnProcess.setEnabled(true);
            _btnConfirm.setEnabled(false);
            _tfOrderItemId.setText("");
            _tfOrderItemQuantity.setText("");
            _tfOrderItemInformation.setText("");
            _tfOrderItemId.setEditable(true);
            _tfOrderItemQuantity.setEditable(true);
        }
        /** Reset for entry finish. */
        public void resetEntryFinish() {
            _btnProcess.setEnabled(false);
            _btnConfirm.setEnabled(false);
            _tfOrderItemId.setText("");
            _tfOrderItemQuantity.setText("");
            _tfOrderItemId.setEditable(false);
            _tfOrderItemQuantity.setEditable(false);
        }

        // Implement Model-View-Controller (MVC) architectural pattern.
        private Model _model;
        // Frame (window).
        private JFrame _frameWindow;
        // Components.
        private JLabel _lblOrderTotalItems;
        private JLabel _lblOrderItemId;
        private JLabel _lblOrderItemQuantity;
        private JLabel _lblOrderItemInformation;
        private JLabel _lblOrderPriceSubtotal;
        private JTextField _tfOrderTotalItems;
        private JTextField _tfOrderItemId;
        private JTextField _tfOrderItemQuantity;
        private JTextField _tfOrderItemInformation;
        private JTextField _tfOrderPriceSubtotal;
        private JButton _btnOpen;
        private JButton _btnProcess;
        private JButton _btnConfirm;
        private JButton _btnOrderView;
        private JButton _btnOrderFinish;
        private JButton _btnOrderNew;
        private JButton _btnExit;
        // Definitions.
        public static final int TEXTFIELD_COLUMNS = 32;
    }
    /** Inner class Controller (Controller) using Model-View-Controller (MVC) architectural pattern. */
    protected class Controller {
        /** Argument constructor. */
        Controller(Model m, View v) {
            _model = m;
            _view = v;
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            // Add listeners to the view.
            _view.addMouseListenerOrderItemId(new MouseListener() {
                public void mouseClicked(MouseEvent e) {}
                public void mouseEntered(MouseEvent e) {}
                public void mouseExited(MouseEvent e) {
                    int id = _model.getDataItemId(_view.getOrderItemId());
                    if(id >= 0) {
                        _view.setOrderItemId(String.valueOf(id));
                    }
                }
                public void mousePressed(MouseEvent e) {}
                public void mouseReleased(MouseEvent e) {}
            });
            _view.addListenerOpen(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    app_mvc2.setWindowVisible(true);
                }
            });
            _view.addListenerProcess(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String p1 = _view.getOrderItemId();
                    String p2 = _view.getOrderItemQuantity();
                    if(!isNullOrEmpty(p1) && !isNullOrEmpty(p2)) {
                        if(_model.createOrder(Integer.parseInt(p1), Integer.parseInt(p2))) {
                            _view.setOrderItemInformation(_model.toStringOrder());
                            _view.setEditableOrderTotalItems(false);
                            _view.setEnabledButton1(false);
                            _view.setEnabledButton2(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "The ID of the CD is invalid.");
                        }
                    }
                }
            });
            _view.addListenerConfirm(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "Item #" + (_model.getOrdersCount() + 1) + " accepted");
                    if(_model.getOrdersCount() == 0) {
                        _model.setOrdersMax(Integer.parseInt(_view.getOrderTotalItems()));
                        _view.setEnabledButton3(true);
                        _view.setEnabledButton4(true);
                    }
                    _model.setOrder();
                    _view.setOrderPriceSubtotal("$" + toStringDecimalRoundTwo(_model.getOrdersSubtotal()));
                    if(_model.getOrdersCount() >= _model.getOrdersMax()) {
                        _view.resetEntryFinish();
                    } else {
                        _view.resetEntry(_model.getOrdersCount() + 1, _model.getOrdersCount());
                    }
                }
            });
            _view.addListenerOrderView(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, _model.toStringOrders());
                }
            });
            _view.addListenerOrderFinish(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _view.setEnabledButton3(false);
                    _view.setEnabledButton4(false);
                    JOptionPane.showMessageDialog(null,
                        "Date: " + _model.getOrderDateTimeTransactionLast() +
                        "\n\nNumber of line items: " + _model.getOrdersCount() +
                        "\n\nItem# / ID / Title / Price / Qty / Disc % / Subtotal:\n\n" + _model.toStringOrders() +
                        "\n\nOrder subtotal: $" + toStringDecimalRoundTwo(_model._ordersSubtotal) +
                        "\n\nTax rate: " + toStringDecimalToPercent(_model.getTaxRate()) +
                        "\n\nTax amount: $" + toStringDecimalRoundTwo(_model.getTaxAmount()) +
                        "\n\nOrder total: $" + toStringDecimalRoundTwo(_model.getOrdersTotal()) +
                        "\n\nThanks for shopping at " + _model.TITLE
                    );
                    _model.setOrdersFinished();
                }
            });
            _view.addListenerOrderNew(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _model.resetOrders();
                    _view.reset();
                }
            });
            _view.addListenerExit(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _model.exit();
                }
            });
        }

        // Implement Model-View-Controller (MVC) architectural pattern.
        private Model _model;
        private View _view;
    }
    /** Round to two decimal places. */
    public static double decimalRoundTwo(double d) {
        DecimalFormat df = new DecimalFormat("0.00");
        return Double.valueOf(df.format(d));
    }
    /** To string, round to two decimal places. */
    public static String toStringDecimalRoundTwo(double d) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(d);
    }
    /** To string, decimal to percent. */
    public static String toStringDecimalToPercent(double d) {
        d *= 100;
        DecimalFormat df = new DecimalFormat("0");
        return df.format(d) + "%";
    }
    /** Is null or empty. */
    public static boolean isNullOrEmpty(String s) {
        if(s == null || s.equals("")) {
            return true;
        } else {
            return false;
        }
    }
    /** Get current data and/or time. */
    public static String getDataTimeNow(String dateFormat) {
        DateFormat df = new SimpleDateFormat(dateFormat);
        Date date = new Date();
        return df.format(date);
    }
    /** Standard constructor. */
    Hw1() {
        Model m = new Model();
        View v = new View(m);
        new Controller(m, v);
        v.setWindowVisible(true);
    }
    /** Start program execution. */
    public static void main(String[] args) {
        // Schedule a job for the event-dispatching thread.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Applications.
                new Hw1();
                app_mvc2 = new Hw1_Extra();
            }
        });
    }

    // Objects.
    private static Hw1_Extra app_mvc2;
    // Definitions.
    public static final String DATA_FILE_READ = "inventory.txt";
    public static final String DATA_FILE_WRITE = "transcations.txt";
}