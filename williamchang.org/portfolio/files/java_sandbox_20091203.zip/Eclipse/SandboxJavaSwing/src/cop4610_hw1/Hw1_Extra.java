/*
Name: William Chang
Course: COP 4610
Assignment title: Program Assignment 1: Event-Driven Programming
Date: 2008-01-30
*/

package cop4610_hw1;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.TransferHandler;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;

/** Class Hw1_Extra (MVC) using Model-View-Controller (MVC) architectural pattern. */
public class Hw1_Extra {
    /** Inner class Model (Model) using Model-View-Controller (MVC) architectural pattern. */
    protected class Model {
        /** Standard constructor. */
        Model() {
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            _items = new HashMap<String, Integer>();
            _itemLabels = new Vector<String>();
        }
        /** Read data file. */
        protected void readDataFile(File f) {
            Scanner fin = null;
            try {
                fin = new Scanner(f).useDelimiter(", *|\n|\r\n|\r");
                while(fin.hasNext()) {
                    // Get tokens.
                    int parameter1 = fin.nextInt();
                    String parameter2 = fin.next();
                    double parameter3 = fin.nextDouble();
                    // Join.
                    String s = parameter2 + " $" + parameter3;
                    _itemLabels.add(s);
                    _items.put(s, parameter1);
                }
            } catch(Exception e) {
                if(e instanceof FileNotFoundException) {
                    System.out.println("Data file not found.");
                } else {
                    e.printStackTrace();
                    System.out.println("Could not interpret file correctly.");
                }
            } finally {
                if(fin != null) {
                    fin.close();
                }
            }
        }
        /** Get items. */
        public Vector<?> getItems() {
            return _itemLabels;
        }
        /** Get items. */
        public Vector<?> getItems(File f) {
            readDataFile(f);
            return _itemLabels;
        }
        /** Reset. */
        public void reset() {
            _items = new HashMap<String, Integer>();
            _itemLabels = new Vector<String>();
        }

        // Collections.
        private HashMap<String, Integer> _items;
        private Vector<String> _itemLabels;
        // Definitions.
        public final String TITLE = "Item List";
    }
    /** Inner class View (View) using Model-View-Controller (MVC) architectural pattern. */
    protected class View {
        /** Argument constructor. */
        View(Model m) {
            _model = m;
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            // Setup window.
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch(Exception e) {
                e.printStackTrace();
            }
            _frameWindow = new JFrame(_model.TITLE);
            _frameWindow.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            // Setup components.
            _fcItems = new JFileChooser();
            _pnlControls = new JPanel();
            _listItems = new JList();
            _listItems.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            _listItems.setBorder(new BevelBorder(BevelBorder.LOWERED));
            _btnFileOpen = new JButton();
            _pnlControls.add(_btnFileOpen);
            _btnListClear = new JButton();
            _pnlControls.add(_btnListClear);
            _btnClose = new JButton();
            _pnlControls.add(_btnClose);
            _frameWindow.getContentPane().add(_pnlControls, BorderLayout.PAGE_END);
            setComponentTexts();
            // Add components to window.
            _frameWindow.getContentPane().add(new JScrollPane(_listItems), BorderLayout.CENTER);
            // Show window.
            _frameWindow.pack();
            _frameWindow.setVisible(false);
            // Set window properties after at the end.
            _frameWindow.setSize(300, 400);
            _frameWindow.setLocationRelativeTo(null);
        }
        public void addListenerFileOpen(ActionListener al) {
            _btnFileOpen.addActionListener(al);
        }
        public void addListenerListClear(ActionListener al) {
            _btnListClear.addActionListener(al);
        }
        public void addListenerClose(ActionListener al) {
            _btnClose.addActionListener(al);
        }
        public void addListenerMouseItems(MouseListener ml) {
            _listItems.addMouseListener(ml);
        }
        public File getFile() {
            int state = _fcItems.showOpenDialog(_frameWindow);
            if(state == JFileChooser.APPROVE_OPTION) {
                return _fcItems.getSelectedFile();
            } else {
                return null;
            }
        }
        public void setComponentTexts() {
            _btnFileOpen.setText("Open File");
            _btnListClear.setText("Clear List");
            _btnClose.setText("Close");
        }
        public void setWindowVisible(boolean b) {
            _frameWindow.setVisible(b);
        }
        public void setItems() {
            File f = getFile();
            if(f != null) {
                _listItems.setListData(_model.getItems(f));
            }
        }
        /** Reset. */
        public void reset() {
            _listItems.setListData(_model.getItems());
        }

        // Implement Model-View-Controller (MVC) architectural pattern.
        private Model _model;
        // Frame (window).
        private JFrame _frameWindow;
        // Components.
        private JPanel _pnlControls;
        private JFileChooser _fcItems;
        private JList _listItems;
        private JButton _btnFileOpen;
        private JButton _btnListClear;
        private JButton _btnClose;
        // Definitions.
        public static final int TEXTFIELD_COLUMNS = 32;
    }
    /** Inner class Controller (Controller) using Model-View-Controller (MVC) architectural pattern. */
    protected class Controller {
        /** Argument constructor. */
        Controller(Model m, View v) {
            _model = m;
            _view = v;
            initCommon();
        }
        /** Initialize common. */
        protected void initCommon() {
            _view.addListenerFileOpen(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _view.setItems();
                }
            });
            _view.addListenerListClear(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _model.reset();
                    _view.reset();
                }
            });
            _view.addListenerClose(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    _view.setWindowVisible(false);
                }
            });
            _view.addListenerMouseItems(new MouseAdapter() {
                public void mousePressed(MouseEvent e){
                    JComponent jc = (JComponent)e.getSource();
                    TransferHandler th = jc.getTransferHandler();
                    th.exportAsDrag(jc, e, TransferHandler.COPY);
                }
            });
        }

        // Implement Model-View-Controller (MVC) architectural pattern.
        private Model _model;
        private View _view;
    }
    /** Standard constructor. */
    Hw1_Extra() {
        m = new Model();
        v = new View(m);
        c = new Controller(m, v);
    }
    /** Get model. */
    public Model getModel() {
        return m;
    }
    /** Get view. */
    public View getView() {
        return v;
    }
    /** Get controller. */
    public Controller getController() {
        return c;
    }
    /** Set window visible. */
    public void setWindowVisible(boolean b) {
        v.setWindowVisible(b);
    }

    // Objects.
    private Model m;
    private View v;
    private Controller c;
}