/**
@file
    HelloSwing.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2008-01-23
    - Modified: 2008-01-30
    .
@note
    References:
    - General:
        - http://data.uta.edu/~ramesh/help/JavaThreads-howto.html
        - http://en.wikipedia.org/wiki/Swing_(Java)
        .
    - Dran and Drop:
        - http://www.java2s.com/Code/Java/Swing-JFC/DragandDropJListandList.htm
        .
    - HashMap:
        - http://forum.java.sun.com/thread.jspa?threadID=607857&messageID=3316854
        .
    - Delimiter:
        - http://www.semiantics.com/?p=25
        - http://java.sun.com/developer/JDCTechTips/2004/tt1201.html
        - http://www.java2s.com/Code/JavaAPI/java.util/ScanneruseDelimiterStringpattern.htm
        .
    - Model View Controller (MVC):
        - http://home.cogeco.ca/~ve3ll/jatutorc.htm
        - http://www.leepoint.net/notes-java/GUI/structure/40mvc.html
        .
    .
*/

package helloworld;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.border.BevelBorder;

public class HelloSwing implements Runnable {
    public void createWindow() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(Exception e) {
            e.printStackTrace();
        }

        // Create window.
        JFrame f = new JFrame("HelloWorldSwing");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create form layout.
        JPanel pnlFormLayout = new JPanel(new SpringLayout());

        // Create form inputs.
        JPanel pnlFormInputs = new JPanel(new SpringLayout());
        createFormInputElements(pnlFormInputs);
        SpringUtilities.makeCompactGrid(pnlFormInputs, pnlFormInputs.getComponentCount() / 2, 2, 6, 6, 6, 6);
        pnlFormLayout.add(pnlFormInputs);

        // Create form controls.
        JPanel pnlFormControls = new JPanel(new SpringLayout());
        createFormControlElements(pnlFormControls);
        SpringUtilities.makeCompactGrid(pnlFormControls, 1, pnlFormControls.getComponentCount(), 6, 6, 6, 6);
        pnlFormLayout.add(pnlFormControls);

        // Add components to window.
        SpringUtilities.makeCompactGrid(pnlFormLayout, 2, 1, 6, 6, 6, 6);
        f.getContentPane().add(pnlFormLayout);

        // Show window.
        f.pack();
        f.setVisible(true);

        // Set window properties after at the end.
        //f.setSize(640, 480);
        f.setLocationRelativeTo(null);
    }
    public void createFormInputElements(JPanel p) {
        // Create label.
        JLabel lbl1 = new JLabel("First Name:", JLabel.TRAILING);
        p.add(lbl1);
        // Create textfield.
        JTextField txt1 = new JTextField(32);
        txt1.setBorder(new BevelBorder(BevelBorder.LOWERED));
        lbl1.setLabelFor(txt1);
        _ht1.put("NameFirst", txt1);
        p.add(txt1);
        // Create label.
        JLabel lbl2 = new JLabel("Last Name:", JLabel.TRAILING);
        p.add(lbl2);
        // Create textfield.
        JTextField txt2 = new JTextField(32);
        txt2.setBorder(new BevelBorder(BevelBorder.LOWERED));
        lbl2.setLabelFor(txt2);
        _ht1.put("NameLast", txt2);
        p.add(txt2);
    }
    public void createFormControlElements(JPanel p) {
        // Create button.
        JButton btn2 = new JButton("Submit");
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Hello " + ((JTextField)_ht1.get("NameFirst")).getText() + " " + ((JTextField)_ht1.get("NameLast")).getText() + "!");
            }
        });
        p.add(btn2);
        // Create button.
        JButton btn1 = new JButton("Exit");
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        p.add(btn1);
    }
    public void output() {
        /*
        // Iterate hashmap.
        for(Integer i : _ht1.keySet()) {
            DataOrder value = _ht1.get(i);
            fout.println(value.toStringFile());
        }
        // Iterate hashmap.
        for (Map.Entry<Integer, DataOrder> entry : _ht1.entrySet()) {
            entry.getKey();
            entry.getValue();
        }
        */
    }
    public void run() {
        createWindow();
    }
    public static void main(String[] args) {
        // Schedule a job (GUI) for the event-dispatching thread.
        //SwingUtilities.invokeLater(new HelloSwing());
        new HelloSwing().createWindow();
    }

    private HashMap<String, JComponent> _ht1 = new HashMap<String, JComponent>();
}