package helloworld;

import java.util.Scanner;

public class Hello {
    public enum Season {SPRING,SUMMER,FALL,WINTER};

    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in);
        String user;

        System.out.printf("Computer Interaction\n\n");
        System.out.println("Enter User Input:");
        user = stdin.next();
        System.out.printf("User entered %s.",user);

        Season s = Season.SUMMER;

        System.out.println();
        System.out.println();
        System.out.println(getNextSeason(s));
        System.out.println();
        System.out.println(Math.log(10D));
        System.out.println(Math.log10(10D));
    }

    public static Season getNextSeason(Season s) {
        if(s.ordinal()>=3)
            return Season.values()[0];
        else {
            int i = s.ordinal();
            return Season.values()[i+1];
        }
    }
}