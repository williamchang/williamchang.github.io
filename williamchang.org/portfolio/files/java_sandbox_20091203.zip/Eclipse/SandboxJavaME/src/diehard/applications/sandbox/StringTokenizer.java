/**
@file
    StringTokenizer.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-05
    - Modified: 2007-11-05
    .
@note
    References:
    - General:
        - http://forum.java.sun.com/thread.jspa?forumID=76&threadID=5143778
        - http://forum.java.sun.com/thread.jspa?forumID=76&threadID=719778
        .
    .
*/

package diehard.applications.sandbox;

/**
 * Class StringTokenizer.
 * @author William Chang
 */
public class StringTokenizer {
    /**
     * Initialise text with value.
     * @param line The line of string.
     */
    public StringTokenizer(String line) {
        // Turn string into byte stream.
        content = line.getBytes();
        stringLength = content.length;
    }
    /**
     * Get characters.
     * @param pointer The point to start.
     * @return The number left.
     */
    final private char getCharacters(int pointer) {
        int number = 0;
        
        try {
            number = (content[pointer] & 0xFF);
        } catch(ArrayIndexOutOfBoundsException e) {
            return '\n';
        }
        
        return (char)number;
    }
    /**
     * Read a next value up to space.
     * @return The string of a token.
     */
    final public String nextToken() {
        StringBuffer tokenValue = new StringBuffer();
        boolean hasChars = false;
        char nextChar = getCharacters(currentCharPointer);
        currentCharPointer++;
        // Exit on space, otherwise add to string.
        while(true) {
            if((nextChar != '\n') && (nextChar != '/') && (nextChar != '(') && (nextChar != ')') && (nextChar != ' ')) {
                tokenValue.append(nextChar);
                hasChars = true;
            }
            //if(((nextChar == '\n') && (hasChars)) || ((nextChar == '/') && (hasChars)) || ((nextChar == '(') && (hasChars)) || ((nextChar == ')') && (hasChars)) || ((nextChar == ' ') && (hasChars)) || (currentCharPointer == stringLength)) {
            if(hasChars || currentCharPointer >= stringLength) {
                boolean pass = true;
                switch(nextChar) {
                    case '\n': case '/': case '(': case ')': case ' ':
                        pass = false;
                        break;
                }
                if(!pass) {break;}
            }
            nextChar = getCharacters(currentCharPointer);
            currentCharPointer++;
        }

        return tokenValue.toString();
    }
    /**
     * Count number of tokens using space as deliminator.
     * @return The number of total tokens in a string.
     */
    public int countTokens() {
        int tokenCount = 1;
        // Count spaces in string, ignoring double spaces and any first and last space.
        int count = stringLength - 1;
        for(int i = 1; i < count; i++) {
            if(((content[i] == ' ') || (content[i] == '/')))//&&(content[i-1]!=' '))
            {
                tokenCount++;
            }
        }
        return tokenCount;
    }
    
    /// Holds content.
    private byte[] content;//=new byte[20000];
    /// Pointers to position reached in string.
    private int currentCharPointer;
    /// Length of string.
    private int stringLength;
}
