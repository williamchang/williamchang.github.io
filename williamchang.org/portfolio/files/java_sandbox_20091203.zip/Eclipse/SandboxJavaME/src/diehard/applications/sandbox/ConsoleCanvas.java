/**
@file
    ConsoleCanvas.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-03
    .
*/

package diehard.applications.sandbox;

/**
 * Class ConsoleAnimation.
 * @author William Chang
 */
public class ConsoleCanvas {
    /** Standard constructor. */
    public ConsoleCanvas() {}
}