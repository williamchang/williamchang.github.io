/**
@file
    PongCanvas.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-03
    .
@note
    References:
    - General:
        - http://www.java2s.com/Code/Java/J2ME/SweepGame.htm
        - http://developers.sun.com/mobility/midp/articles/threading2/
        - http://devlinslab.blogspot.com/2007/10/basic-game-template-part-1.html
        .
    .
*/

package diehard.applications.sandbox;

import java.io.IOException;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.lcdui.game.Sprite;

/**
 * Class PongCanvas.
 * @author William Chang
 */
public class PongCanvas extends GameCanvas implements Runnable, CommandListener {
    /** Inherited constructor. */
    public PongCanvas() {
        // Call superclass.
        super(true);
        // Instantiate this.
        if(!instantiateThis()) return;
    }
    /**
     * Argument constructor.
     * @param m The MIDlet to be used as a reference.     
     * @param next The next displayable (screen) after this.
     */
    public PongCanvas(MainMIDlet m, Displayable next) {
        // Call superclass.
        super(true);
        // Set reference to MIDlet for callbacks.
        PongCanvas._midlet = m;
        // Set reference to displayable for callbacks.
        PongCanvas._nextDisplayable = next;
        // Instantiate this.
        if(!instantiateThis()) return;
    }
    /** Instantiate this. */
    public boolean instantiateThis() {
        // Set initial properties.
        _started = false;
        _delay = 30;
        _ballX = getWidth() / 2;
        _ballY = getHeight() / 2;
        _ballDirection = 1;
        // Create commands.
        this._cmdExit = new Command("Exit", Command.EXIT, 1);
        // Add to displayable.
        this.addCommand(_cmdExit);
        // Capture events.
        this.setCommandListener(this);
        
        return true;
    }
    /** Get displayable (screen). */
    public Displayable getDisplayable() {
        return this;
    }
    /** Get thread. */
    public Thread getThread() {
        return _thread;
    }
    /** Start. */
    public void start() {
        try {
            _ballImg = Image.createImage("/ball.png");
        } catch(IOException e) {
            System.out.println(e);
        }
        
        _ballSprite = new Sprite(_ballImg, 3, 3);
        _ballSprite.defineReferencePixel(2, 2);
        _ballSprite.setRefPixelPosition(_ballX, _ballY);
        
        // The system starts a new thread to invoke the Runnable's run() method.
        _thread = new Thread(this);
        _thread.start();
        _started = true;
    }
    /** Stop. */
    public void stop() {
        _thread = null;
        _started = false;
    }
    /** Move ball. */
    private void moveBall() {
        if(_ballDirection == 0) {
            _ballX -= _ballXVel;
            _ballY -= _ballYVel;
        } else if(_ballDirection == 1) {
            _ballX += _ballXVel;
            _ballY -= _ballYVel;
        } else if(_ballDirection == 2) {
            _ballX += _ballXVel;
            _ballY += _ballYVel;
        } else if(_ballDirection == 3) {
            _ballX -= _ballXVel;
            _ballY += _ballYVel;
        }
        
        if(_ballDirection == 0 && _ballX < 0) {
            _ballDirection = 1;
        } else if(_ballDirection == 0 && _ballY < 0) {
            _ballDirection = 3;
        } else if(_ballDirection == 1 && _ballY < 0) {
            _ballDirection = 2;
        } else if(_ballDirection == 1 && _ballX > getWidth()) {
            _ballDirection = 0;
            if(_delay > 5) _delay--;
        } else if(_ballDirection == 2 && _ballY > getHeight()) {
            _ballDirection = 1;
        } else if(_ballDirection == 2 && _ballX > getWidth()) {
            _ballDirection = 3;
            if(_delay > 5) _delay--;
        } else if(_ballDirection == 3 && _ballY > getHeight()) {
            _ballDirection = 0;
        } else if(_ballDirection == 3 && _ballX < 0) {
            _ballDirection = 2;
        }
    }
    /**
     * Create background.
     * @param g The graphics object to be used for rendering the canvas.
     */
    private void createBackground(Graphics g) {
        g.setColor(0x000000);
        g.fillRect(0, 0, getWidth(), getHeight());
    }
    /**
     * Render one frame.
     * @param g The graphics object to be used for rendering the canvas.
     */
    private void renderOneFrame(Graphics g) {
        // Render graphics.
        createBackground(g);
        // Animate from previous frame.
        moveBall();
        // Render sprites.
        _ballSprite.setRefPixelPosition(_ballX, _ballY);
        _ballSprite.paint(g);
    }
    /**
     * Run is called by Thread.start(). When the thread returns from the run()
     * method, the system terminates the thread. Abstract method implemented
     * by Runnable.
     */
    public void run() {
        // Get off-screen buffer.
        Graphics g = getGraphics();
        while(_started) {
            // Render one frame.
            renderOneFrame(g);
            // Flushes the off-screen buffer to the display.
            flushGraphics();
            try {Thread.sleep(_delay);}
            catch(InterruptedException e) {}
        }
    }
    /**
     * Action event. Abstract method implemented by CommandListener.
     * @param c User interface command requested.
     * @param d Screen object initiating the request.
     */
    public void commandAction(Command c, Displayable d) {
        if(c == _cmdExit) {
            stop();
            Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
        }
    }

    /// Ball image.
    private Image _ballImg;
    /// Ball sprite.
    private Sprite _ballSprite;
    /// Ball horizontal position, primitive data type.
    private int _ballX;
    /// Ball vertical position, primitive data type.
    private int _ballY;
    /// Ball horizontal velocity, primitive data type.
    private final static int _ballXVel = 3;
    /// Ball vertical velocity, primitive data type.
    private final static int _ballYVel = 1;
    /// Ball direction, primitive data type.
    private int _ballDirection;
    /// Frame delay.
    private int _delay;
    /// Flag indicating running thread.
    private boolean _started;
    /// Exit command.
    private Command _cmdExit;
    /// Thread instance.
    private Thread _thread;
    /// Screen to display after this.
    private static Displayable _nextDisplayable;
    /// MIDlet used for callbacks.
    private static MainMIDlet _midlet;
}
