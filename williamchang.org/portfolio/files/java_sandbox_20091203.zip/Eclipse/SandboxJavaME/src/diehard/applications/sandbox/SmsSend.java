/**
@file
    SmsSend.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-05
    .
@note
    References:
    - General:
        - http://developers.sun.com/mobility/midp/articles/wma2/
        - http://j2mepolish.org/javadoc/j2me/de/enough/polish/messaging/MessageListener.html
        - http://developers.sun.com/dev/edu/camps/demos/midp_demo/download.html
        - http://www.javaworld.com/javaworld/jw-04-2006/jw-0417-push.html
        - http://bittyjava.wordpress.com/2006/10/27/im-sending-out-an-sms/
        - http://www.ibm.com/developerworks/wireless/library/wi-extendj2me/
        - http://www.devx.com/wireless/Article/22266/0/page/1
        - http://web.mit.edu/bentley/www/mobile/j2meguide/
        .
    .
*/

package diehard.applications.sandbox;

import java.io.IOException;
import javax.microedition.io.Connector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.TextBox;
import javax.microedition.lcdui.TextField;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.TextMessage;

/**
 * Class SmsSend. Wireless messaging API (WMA).
 * @author William CHang
 */
public class SmsSend implements Runnable, CommandListener {
    /** Standard constructor. */
    public SmsSend() {}
    /**
     * Argument constructor.
     * @param m The MIDlet to be used as a reference.
     * @param next The next displayable (screen) after this.
     */
    public SmsSend(MainMIDlet m, Displayable next) {
     // Set reference to MIDlet for callbacks.
        SmsSend._midlet = m;
        // Set reference to displayable for callbacks.
        SmsSend._nextDisplayable = next;
        // Instantiate this.
        if(!instantiateThis()) return;
    }
    /** Instantiate this. */
    public boolean instantiateThis() {
         // Set initial properties.
        _smsPort = _midlet.getAppProperty("SMS-Port");
        _txtMessage = new TextBox("Enter Message", null, 65535, TextField.ANY);
        // Create commands.
        _cmdExit = new Command("Exit", Command.EXIT, 1);
        _cmdCancel = new Command("Cancel", Command.CANCEL, 1);
        _cmdSend = new Command("Send", Command.STOP, 1);
        // Add to displayable.
        _txtMessage.addCommand(_cmdCancel);
        _txtMessage.addCommand(_cmdSend);
        // Capture events.
        _txtMessage.setCommandListener(this); 
        
        
        _alrSending = new Alert("SMS", null, null, AlertType.INFO);
        _alrSending.setTimeout(5000);
        _alrSending.setCommandListener(this);
        
        
        return true;
    }
    /**
     * Send message.
     * @param smsAddress The phone number to send.
     * @param messageSend The message to send.
     */
    public boolean send(String smsAddress) {
        if(!SmsSend.isValidPhoneNumber(smsAddress)) {
            Alert a = new Alert("Error");
            a.setString("Invalid phone number");
            Display.getDisplay(_midlet).setCurrent(a, _nextDisplayable);
            return false;
        }
        _alrSending.setString("Sending message to " + smsAddress + "...");
        _smsAddress = smsAddress;
        Display.getDisplay(_midlet).setCurrent(_txtMessage);

        return true;
    }
    /**
     * Check the phone number for validity. Valid phone numbers contain
     * only the digits 0 thru 9, and may contain * a leading '+'.
     * @param number The phone number.
     */
    public static boolean isValidPhoneNumber(String number) {
        char[] chars = number.toCharArray();
        if(chars.length == 0) {
            return false;
        }
        int startPos = 0;
        // Initial '+' is valid.
        if(chars[0] == '+') {
            startPos = 1;
        }
        for(int i = startPos; i < chars.length; ++i) {
            if(!Character.isDigit(chars[i])) {
                return false;
            }
        }

        return true;
    }
    /**
     * Run is called by Thread.start(). When the thread returns from the run()
     * method, the system terminates the thread. Abstract method implemented
     * by Runnable.
     */
    public void run() {
        // Setup url.
        String smsProtocol = "sms://";
        String smsPort = "50000";
        String smsUrl = smsProtocol + _smsAddress + ":" + smsPort;
        // Open the message connection.
        try {
            MessageConnection c = (MessageConnection)Connector.open(smsUrl);
            try {
                TextMessage m = (TextMessage)c.newMessage(MessageConnection.TEXT_MESSAGE);
                m.setAddress(smsUrl);
                m.setPayloadText(_txtMessage.getString());
                c.send(m);
            } finally {
                c.close();
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Action event. Abstract method implemented by CommandListener.
     * @param c User interface command requested.
     * @param d Screen object initiating the request.
     */
    public void commandAction(Command c, Displayable d) {
        try {
            if(c == _cmdExit || c == Alert.DISMISS_COMMAND) {
                Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
            } else if(c == _cmdCancel) {
                Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
            } else if(c == _cmdSend) {
                Display.getDisplay(_midlet).setCurrent(_alrSending);
                _started = true;                
                // The system starts a new thread to invoke the Runnable's run() method.
                _thread = new Thread(this);
                _thread.start();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /// Address to send .
    private String _smsAddress;
    /// Port to send.
    private String _smsPort;
    /// Flag indicating running thread and signal processing.
    private boolean _started;
    /// Send command.
    private Command _cmdSend;
    /// Cancel command.
    private Command _cmdCancel;
    /// Exit command.
    private Command _cmdExit;
    /// Alert message is being sent displayable.
    private Alert _alrSending;
    /// User message displayable.
    private TextBox _txtMessage;
    /// Thread instance  for asynchronous networking.
    private Thread _thread;
    /// Screen to display after this.
    private static Displayable _nextDisplayable;
    /// MIDlet used for callbacks.
    private static MainMIDlet _midlet;
}
