/**
@file
    MainMIDlet.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-06
    .
@note
    References:
    - General:
        - http://java.sun.com/javame/reference/index.jsp
        - http://discussion.forum.nokia.com/forum/showthread.php?t=100708
        - http://www.microjava.com/developer/fss/graphics?content_id=1835
        .
    .
*/

package diehard.applications.sandbox;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.Display;

/**
 * Class MainMIDlet.
 * @author William Chang
 */
public class MainMIDlet extends MIDlet {
    /** Inherited constructor. */
    public MainMIDlet() {}
    /** Instantiate this. */
    public boolean instantiateThis() {
        // Get display from device.
        _display = Display.getDisplay(this);
        // Initialize applications.
        appConsole = new Console(this);
        //appSmsWireless = new SmsReceive(this, appConsole.getDisplayable());
        appSmsWireless = null;
        //appSmsWireless.startReceiving();
        appIntroduction = new IntroductionCanvas(this, appConsole.getDisplayable());
        // Set display to device.
        _display.setCurrent(appIntroduction.getDisplayable());
        
        return true;
    }
    /** Exit. No need to call destroyApp(true) because it is empty. */
    public void exit() {
        Display.getDisplay(this).setCurrent(null);
        notifyDestroyed();
    }
    /** Get system information. */
    public String getSystemInformation() {
        String s = "System Information:\n";
        String end = "\n";
        s += "MIDlet Vendor: " + getAppProperty("MIDlet-Vendor") + end;
        s += "MIDlet Name: " + getAppProperty("MIDlet-Name") + end;
        s += "MIDlet Version: " + getAppProperty("MIDlet-Version") + end;
        s += "MIDlet Jar Size: " + getAppProperty("MIDlet-Jar-Size") + end;
        s += "MIDlet Jar URL: " + getAppProperty("MIDlet-Jar-URL") + end;
        s += "MicroEdition Profile: " + getAppProperty("MicroEdition-Profile") + end;
        s += "MicroEdition Configuration: " + getAppProperty("MicroEdition-Configuration") + end;
        s += "SMS Port: " + getAppProperty("SMS-Port") + end;
        s += "\n";
        
        return s;
    }
    /** Only the device will call this life-cycle method. Abstract method implemented by MIDlet. */
    public void startApp() throws MIDletStateChangeException {
        if(!_started) {
            // Instantiate this.
            if(!instantiateThis()) return;
            _started = true;
        }
    }
    /** Only the device will call this life-cycle method. Abstract method implemented by MIDlet. */
    public void pauseApp() {}
    /** Only the device will call this life-cycle method. Abstract method implemented by MIDlet. */
    public void destroyApp(boolean unconditional) throws MIDletStateChangeException {}
    
    /// Title application.
    public IntroductionCanvas appIntroduction;
    /// Console application.
    public Console appConsole;
    /// SMS application.
    public SmsReceive appSmsWireless;
    /// Display object.
    private Display _display;
    /// Flag indicating first call of startApp().
    private boolean _started;
}