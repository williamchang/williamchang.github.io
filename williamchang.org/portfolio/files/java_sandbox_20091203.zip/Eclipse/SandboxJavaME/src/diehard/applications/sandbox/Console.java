/**
@file
    Console.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-06
    .
@note
    References:
    - General:
        - http://www.onjava.com/pub/a/onjava/excerpt/wirelessjava_ch5/index2.html
        - http://turing.ace.uci.edu/~karan.kamdar/j2me.html
        .
    - Custom Items:
        - http://developers.sun.com/mobility/midp/ttips/customitem/
        .
    - Switch String:
        - http://www.xefer.com/2006/12/switchonstring
        .
    .
*/

package diehard.applications.sandbox;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.ItemStateListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextBox;
import javax.microedition.lcdui.TextField;

/**
 * Class Console.
 * @author William Chang
 */
public class Console implements CommandListener, ItemStateListener {
    /** Standard constructor. */
    public Console() {}
    /**
     * Argument constructor.
     * @param m The MIDlet to be used as a reference.     
     */
    public Console(MainMIDlet m) {
        // Set reference to MIDlet for callbacks.
        Console._midlet = m;
        
        // Instantiate this.
        if(!instantiateThis()) return;
        // Create displayables.
        createInputDisplayable();
        createOutputDisplayable();
        // Set first displyable.
        _currentDisplayable = _txtOutput;
    } /** Instantiate this. */
    public boolean instantiateThis() {
        return true;
    }
    /** Run input */
    public void runInput() {
        String userInput = _txfInput.getString().toLowerCase();
        String msgError = " is not recognized as a command.\n\n";
        String msgExecuted = " executed.\n\n";
        
        StringTokenizer t = new StringTokenizer(userInput);
        String cmd1 = t.nextToken();
        
        if(userInput.equals("hello world")) {
            updateOutput("\'" + userInput + "\'" + msgExecuted);
            updateOutput("Device replied hello world!\n\n");
        } else if(cmd1.equals("pong")) {
            PongCanvas app = new PongCanvas(_midlet, _txtOutput);
            app.start();
            Display.getDisplay(_midlet).setCurrent(app.getDisplayable());
            updateOutput("\'" + userInput + "\'" + msgExecuted);
        } else if(cmd1.equals("sms")) {
            String cmd2 = t.nextToken();
            if(cmd2.equals("send")) {
                SmsSend s = new SmsSend(_midlet, _txtOutput);
                String cmd3 = t.nextToken();
                if(s.send(cmd3)) {
                    updateOutput("\'" + userInput + "\'" + msgExecuted + "Your SMS sent successfully.");
                } else {
                    updateOutput("\'" + userInput + "\'" + msgExecuted + "Error with SMS Send.");
                }
            } else {
                if(_midlet.appSmsWireless != null) {
                    Display.getDisplay(_midlet).setCurrent(_midlet.appSmsWireless.getDisplayable());
                    updateOutput("\'" + userInput + "\'" + msgExecuted);
                } else {
                    updateOutput("\'" + userInput + "\'" + " can't access system's API because this application is not signed.\n\n");
                }
            }
        } else {
            updateOutput("\'" + userInput + "\'" + msgError);
            return;
        }
        
        _txfInput.setString("");
    }
    /** Update output */
    public void updateOutput(String s) {
        _txtOutput.insert(s, _txtOutput.getCaretPosition());
    }
    /** Create input displayable (screen). */
    private void createInputDisplayable() {
        // Create items.
        _frmInput = new Form("Console");
        _txfInput = new TextField("Input:", "", 160, TextField.ANY);
        // Create commands.
        _cmdCancel = new Command("Cancel", Command.BACK, 1);
        _cmdExecute = new Command("Execute", Command.SCREEN, 1);
        // Add to displayable.
        _frmInput.append(_txfInput);
        _frmInput.addCommand(_cmdCancel);
        _frmInput.addCommand(_cmdExecute);
        // Capture events.
        _frmInput.setCommandListener(this);        
    }
    /** Create output displayable (screen). */
    private void createOutputDisplayable() {
        // Create items.
        _txtOutput = new TextBox("Console", "", 65535, TextField.ANY);
        _txtOutput.setString(_midlet.getSystemInformation());
        // Create commands.
        _cmdExit = new Command("Exit", Command.EXIT, 1);
        _cmdInput = new Command("Input", Command.SCREEN, 1);
        // Add to displayable.
        _txtOutput.addCommand(_cmdExit);
        _txtOutput.addCommand(_cmdInput);
        // Capture events.
        _txtOutput.setCommandListener(this);
    }
    /** Get displayable (screen). */
    public Displayable getDisplayable() {
        return _currentDisplayable;
    }
    /**
     * Action event. Abstract method implemented by CommandListener.
     * @param c user interface command requested.
     * @param d screen object initiating the request.
     */
    public void commandAction(Command c, Displayable d) {
        if(c == _cmdExit) {
            _midlet.exit();
        } else if(c == _cmdInput) {
            Display.getDisplay(_midlet).setCurrent(_frmInput);
        } else if(c == _cmdCancel) {
            Display.getDisplay(_midlet).setCurrent(_txtOutput);
        } else if(c == _cmdExecute) {
            Display.getDisplay(_midlet).setCurrent(_txtOutput);
            runInput();
        }
    }
    /**
     * Changed event. Abstract method implemented by ItemStateListener.
     * @param o The item that was changed.
     */
    public void itemStateChanged(Item o) {}

    /// Input item.
    private TextField _txfInput;
    /// Submit command.
    private Command _cmdExecute;
    /// Cancel command.
    private Command _cmdCancel;
    /// Setup command.
    private Command _cmdInput;
    /// Exit command.
    private Command _cmdExit;
    /// Output displayable.
    private TextBox _txtOutput;
    /// Form displayable.
    private Form _frmInput;
    /// Display used for callbacks.
    private static Displayable _currentDisplayable;
    /// MIDlet used for callbacks.
    private static MainMIDlet _midlet;
}