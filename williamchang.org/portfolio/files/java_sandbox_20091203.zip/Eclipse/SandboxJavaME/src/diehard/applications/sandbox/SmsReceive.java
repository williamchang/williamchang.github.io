/**
@file
    SmsReceive.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-05
    .
@note
    References:
    - General:
        - http://developers.sun.com/mobility/midp/articles/wma2/
        - http://j2mepolish.org/javadoc/j2me/de/enough/polish/messaging/MessageListener.html
        - http://developers.sun.com/dev/edu/camps/demos/midp_demo/download.html
        - http://www.javaworld.com/javaworld/jw-04-2006/jw-0417-push.html
        - http://bittyjava.wordpress.com/2006/10/27/im-sending-out-an-sms/
        - http://www.ibm.com/developerworks/wireless/library/wi-extendj2me/
        - http://www.devx.com/wireless/Article/22266/0/page/1
        - http://web.mit.edu/bentley/www/mobile/j2meguide/
        .
    .
*/

package diehard.applications.sandbox;

import java.io.IOException;
import javax.microedition.io.Connector;
import javax.microedition.io.PushRegistry;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.wireless.messaging.Message;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.MessageListener;
import javax.wireless.messaging.TextMessage;

/**
 * Class SmsReceive. Push functionalty and wireless messaging API (WMA).
 * @author William Chang
 */
public class SmsReceive implements Runnable, CommandListener, MessageListener {
    /** Standard constructor. */
    public SmsReceive() {}
    /**
     * Argument constructor.
     * @param m The MIDlet to be used as a reference.
     * @param next The next displayable (screen) after this.
     */
    public SmsReceive(MainMIDlet m, Displayable next) {
        // Set reference to MIDlet for callbacks.
        SmsReceive._midlet = m;
        // Set reference to displayable for callbacks.
        SmsReceive._nextDisplayable = next;
        // Instantiate this.
        if(!instantiateThis()) return;
    }
    /** Instantiate this. */
    public boolean instantiateThis() {
        // Set initial properties.
        _smsPort = _midlet.getAppProperty("SMS-Port");
        _alrContent = new Alert("SMS Receive");
        _alrContent.setTimeout(Alert.FOREVER);
        _alrContent.setString("Not receiving.");
        // Create commands.
        _cmdExit = new Command("Exit", Command.EXIT, 1);
        _cmdStop = new Command("Stop", Command.STOP, 1);
        // Add to displayable.
        _alrContent.addCommand(_cmdExit);
        _alrContent.addCommand(_cmdStop);
        // Capture events.
        _alrContent.setCommandListener(this);
        
        return true;
    }
    /** Get displayable (screen). */
    public Displayable getDisplayable() {
        return _alrContent;
    }
    /** Get thread. */
    public Thread getThread() {
        return _thread;
    }
    /** Start receiving wireless messages. */
    public void startReceiving() {
        // Setup url.
        String smsProtocol = "sms://";
        String smsPort = "50000";
        String smsUrl = smsProtocol + ":" + smsPort;
        // Open the message connection.
        if(_smsConnection == null) {
            try {
                _smsConnection = (MessageConnection)Connector.open(smsUrl);
                _smsConnection.setMessageListener(this);
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
        // Initialize the text if we were started manually.
        _connections = PushRegistry.listConnections(true);
        if(_connections == null || _connections.length == 0) {
            _alrContent.setString("Waiting for SMS on port " + smsPort + "...");
        }

        _started = true;
        // The system starts a new thread to invoke the Runnable's run() method.
        _thread = new Thread(this);
        _thread.start();
        
        Display.getDisplay(_midlet).setCurrent(_alrContent);
    }
    /** Stop receiving wireless messages. */
    public void stopReceiving() {
        _thread = null;
        if(_smsConnection != null) {
            try {
                _smsConnection.close();
            } catch(IOException e) {
                // Ignore any errors on shutdown.
            }
        }
        _started = false;
    }
    /**
     * Run is called by Thread.start(). When the thread returns from the run()
     * method, the system terminates the thread. Abstract method implemented
     * by Runnable.
     */
    public void run() {
        // Check for SMS connection.
        try {
            // Message reading thread.
            _msgReceived = _smsConnection.receive();
            if(_msgReceived != null && _msgReceived instanceof TextMessage) {
                _senderSmsAddress = _msgReceived.getAddress(); 
                _alrContent.setTitle("From: " + _senderSmsAddress);
                _alrContent.setString(((TextMessage)_msgReceived).getPayloadText());
                Display.getDisplay(_midlet).setCurrent(_alrContent);
            }
        } catch(IOException e) {
            // e.printStackTrace();
        }
    }
    /**
     * Action event. Abstract method implemented by CommandListener.
     * @param c User interface command requested.
     * @param d Screen object initiating the request.
     */
    public void commandAction(Command c, Displayable d) {
        try {
            if(c == _cmdExit || c == Alert.DISMISS_COMMAND) {
                Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
            } else if(c == _cmdStop) {
                stopReceiving();
                Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * Asynchronous incoming message notification. Abstract method implemented by MessageListener.
     * @param c The MessageConnection where the incoming message has arrived.
     */
    public void notifyIncomingMessage(MessageConnection c) {
        if(_thread == null) {
            _thread = new Thread(this);
            _thread.start();
            _started = true;
        }
    }

    /// Connections array string.
    private String[] _connections;
    /// Address of sender string.
    private String _senderSmsAddress;
    /// Port to listen for SMS messages.
    private String _smsPort;
    /// SMS message connection for inbound text messages.
    private MessageConnection _smsConnection;
    /// Message read from the network.
    private Message _msgReceived;
    /// Alert displayable. Contents of the fetched URL.
    private Alert _alrContent;
    /// Flag indicating running thread and signal processing.
    private boolean _started;
    /// Stop command.
    private Command _cmdStop;
    /// Exit command.
    private Command _cmdExit;
    /// Thread instance  for asynchronous networking.
    private Thread _thread;
    /// Screen to display after this.
    private static Displayable _nextDisplayable;
    /// MIDlet used for callbacks.
    private static MainMIDlet _midlet;
}
