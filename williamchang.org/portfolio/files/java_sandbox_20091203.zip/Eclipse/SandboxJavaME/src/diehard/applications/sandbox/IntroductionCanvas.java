/**
@file
    IntroductionCanvas.java
@brief
    Coming soon.
@author
    William Chang
@version
    0.1
@date
    - Created: 2007-11-03
    - Modified: 2007-11-03
    .
@note
    References:
    - General:
        - http://www.dbarnes.com/midlet/midlet-title-screen/
        .
    .
*/

package diehard.applications.sandbox;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Font;

/**
 * Class IntroductionCanvas.
 * @author William Chang
 */
public class IntroductionCanvas extends Canvas implements CommandListener {
    /** Standard constructor. */
    public IntroductionCanvas() {}
    /**
     * Argument constructor.
     * @param m The MIDlet to be used as a reference.     
     * @param next The next displayable (screen) after this.
     */
    public IntroductionCanvas(MainMIDlet m, Displayable next) {
        // Set reference to MIDlet for callbacks.
        IntroductionCanvas._midlet = m;
        // Set reference to displayable for callbacks.
        IntroductionCanvas._nextDisplayable = next;
        
        // Create commands.
        this._cmdExit = new Command("Exit", Command.EXIT, 1);
        this._cmdSkip = new Command("Skip", Command.SCREEN, 1);
        // Add to displayable.
        this.addCommand(_cmdExit);
        this.addCommand(_cmdSkip);
        // Capture events.
        this.setCommandListener(this);
    }
    /** Get displayable (screen). */
    public Displayable getDisplayable() {
        return this;
    }
    /**
     * Paint one frame to display. Abstract method implemented by Canvas.
     * @param g The graphics object to be used for rendering the canvas.
     */
    protected void paint(Graphics g) {
        // Get dimensions.
        int canvasWidth = getWidth();
        int canvasHeight = getHeight();
         // Clear and set background.
        g.setColor(0x5672B2);
        g.fillRect(0, 0, canvasWidth, canvasHeight);
         // Draw title text.
        Font titleFont = Font.getFont(
                Font.FACE_SYSTEM,
                Font.STYLE_BOLD,
                Font.SIZE_LARGE);
        g.setFont(titleFont);
        g.setColor(0xFFFFFF);
        g.drawString(
            "William Chang",
            canvasWidth / 2,
            canvasHeight / 4,
            Graphics.BASELINE | Graphics.HCENTER);
    }
    /**
     * Called when a key is pressed.
     * @param keyCode The key code of the key that was pressed.
     */
    protected void keyPressed(int keyCode) {
        // Get game action associated with key pressed.
        int gameAction = getGameAction(keyCode);
        // Change from title screen to the next screen.
        if(gameAction == FIRE) {
            Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
            return;
        }
    }
    /**
     * Action event. Abstract method implemented by CommandListener.
     * @param c user interface command requested.
     * @param d screen object initiating the request.
     */
    public void commandAction(Command c, Displayable d) {
        if(c == _cmdExit) {
            _midlet.exit();
        } else if(c == _cmdSkip) {
            Display.getDisplay(_midlet).setCurrent(_nextDisplayable);
        }
    }
    
    /// Skip command.
    private Command _cmdSkip;
    /// Exit command.
    private Command _cmdExit;
    /// Screen to display after this.
    private static Displayable _nextDisplayable;
    /// MIDlet used for callbacks.
    private static MainMIDlet _midlet;
}
